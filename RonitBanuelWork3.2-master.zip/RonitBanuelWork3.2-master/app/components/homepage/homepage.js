app.controller('homepage', ['localStorageService', '$scope', '$http', '$location', function (localStorageService, $scope, $http, $location) {
    // $scope.login = false;
    let URL='http://localhost:3000/';
   // console.log(localStorageService.keys());
   if(localStorageService.get('token')!=null){
    $location.path('/profile');
    $location.replace();
   }

    $scope.gotoRetrieve = function () {
        $location.path('/RetrievePass');
        $location.replace();

    };

    $scope.gotoRegister = function () {
        $location.path('/register');
        $location.replace();

    };

    $scope.User = { username: "", password: "" }
    $scope.Wrong = false;
    $scope.returned;
    $scope.Log = function () {
        $http.post(URL+'guests/Login', $scope.User)
            .then(Response => {
                $scope.returned = Response.data;
                if ($scope.returned.success == true) {
                    
                    if(localStorageService.get('name')!=$scope.User.username){
                        localStorageService.clearAll();
                    }
                    localStorageService.set('token', $scope.returned.token);
                    localStorageService.set('name', $scope.User.username);
                    if(localStorageService.get('fav')==null){
                        localStorageService.set('fav',[]);
                    }
                    $scope.login = true;
                    toLog($scope.User.username);
                    $location.path('/profile');
                    $location.replace();
                }
                else {
                    $scope.Wrong = true;
                }
            })

    }

    $http.get(URL+"guests/RandomPoints/3")
        .then(Response => {
            $scope.points = Response.data;
        })

    $scope.Info = function (x) {
        $location.path('/pointinfo/' + x);
        $location.replace();
    };

}])

