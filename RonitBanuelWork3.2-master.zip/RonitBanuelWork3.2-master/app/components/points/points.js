app.controller('points', ['localStorageService', '$scope', '$http', '$location', function (localStorageService, $scope, $http, $location) {
    let URL = 'http://localhost:3000/';
    $http.defaults.headers.common['x-access-token'] = localStorageService.get('token');
    $scope.login = false;
    if (localStorageService.get('token') != null)
        $scope.login = true;


    $http.get(URL + "guests/Points")
        .then(Response => {
            $scope.points = Response.data;
        })

    $scope.Info = function (x) {

        $location.path('/pointinfo/' + x);
        $location.replace();
    };
    $scope.category = "All";
    $scope.Sort = function () {
        if ($scope.category == "All") {
            $http.get(URL + "guests/Points")
                .then(Response => {
                    $scope.points = Response.data;
                })
        }
        else {
            $http.get(URL + "guests/PointsbyCategory/" + $scope.category)
                .then(Response => {
                    $scope.points = Response.data;

                })
        }
    }
    $scope.SmallToBig = false;
    $scope.changeStatus = function () {
        $scope.SmallToBig = !$scope.SmallToBig;
    }


    function ifCointains(id) {
        var arr = localStorageService.keys();
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] == id)
                return true;
        }
        return false;
    }

    // if (localStorageService.get('fav') == null) {
    //     $scope.counter = localStorageService.keys().length - 2;
    // }
   // else {
        $scope.counter = localStorageService.keys().length - 3;
   // }
    $scope.changeSave = function (id) {
        if (!ifCointains(id)) {
            localStorageService.set(id, $scope.points[id - 1]);
            $scope.fav = localStorageService.get('fav');

            $scope.counter = localStorageService.keys().length - 3;
            $scope.fav[$scope.fav.length] = $scope.points[id - 1];

            localStorageService.set('fav', $scope.fav);
        }

        else {
            if (ifCointains(id)) {

                localStorageService.remove(id);
                $scope.fav = localStorageService.get('fav');

                deleteFromArr(id);

                localStorageService.set('fav', $scope.fav);
                $scope.counter = localStorageService.keys().length - 3;

            }

        }
    }
    function deleteFromArr(id) {
        var arr = $scope.fav;
        for (var i = 0; i < arr.length; i++) {

            if (arr[i].PointID == id) {
                $scope.fav.splice(i, 1);

            }
        }
    }

    $scope.ifSavedfun = function (id) {

        return (ifCointains(id));


    }


    $scope.goToFav = function () {
        $location.path('/favoritepoint');
        $location.replace();
    }


}])