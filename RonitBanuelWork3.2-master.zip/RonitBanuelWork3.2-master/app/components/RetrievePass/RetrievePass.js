app.controller('RetrievePass', ['$scope', '$http', function ($scope, $http) {
    let URL='http://localhost:3000/';
    $scope.question;
    $scope.user = { username: "" };
    $scope.isMail = false;
    $scope.error = false;
    $scope.answers = { answer1: "", answer2: "" }
    $scope.wrongans = false;
    $scope.getUser = function () {
        if ($scope.user.username == "")
            $scope.error = true;
        else {
            $http.get(URL+'guests/VerificationQuestions/' + $scope.user.username)
                .then(Response => {
                    $scope.question = Response.data;
                    if ($scope.question == "no such user") {
                        $scope.error = true;
                    }
                    else {
                        $scope.isMail = true;
                        $scope.error = false;
                    }
                })
                .catch((err) => {

                  
                })
        }

    }

    $scope.retrieve = function () {
        $http.post(URL+'guests/password', { 'username': $scope.user.username, 'answer1': $scope.answers.answer1, 'answer2': $scope.answers.answer2 })
            .then(Response => {

                $scope.passwordreturn = Response.data;
                if ($scope.passwordreturn == "one or more answers doesnt match")
                    $scope.wrongans = true;
                else {
                    $scope.password = $scope.passwordreturn;
                    $scope.wrongans = false;
                }
            })
    }
}])