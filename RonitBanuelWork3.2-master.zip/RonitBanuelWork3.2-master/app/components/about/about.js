app.controller('about', ['$scope', '$http', function ($scope, $http) {

    
  
}])