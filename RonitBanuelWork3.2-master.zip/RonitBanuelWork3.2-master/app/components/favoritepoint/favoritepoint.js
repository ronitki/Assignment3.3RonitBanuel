app.controller('favoritepoint', ['localStorageService', '$scope', '$http', '$location', function (localStorageService, $scope, $http, $location) {
    let URL = 'http://localhost:3000/';
    $scope.login = false;
    if (localStorageService.get('token') != null)
        $scope.login = true;
    $http.defaults.headers.common['x-access-token'] = localStorageService.get('token');
    $scope.ByUser = false;
    $scope.points = [];
    var tempKeys = localStorageService.keys();
    var counter = 0;
    if (localStorageService.get('fav').length == 0) {
        
        for (var i = 0; i < tempKeys.length -3; i++) {
            if (tempKeys[i] == 'name' || tempKeys[i] == 'token') { }
            else {
                $scope.points[counter] = localStorageService.get(tempKeys[i]);
                counter++;
            }
        }
    }
    else {
        $scope.points = localStorageService.get('fav');
    }

    $scope.range = function (min, max, step) {
        step = step || 1;
        var input = [];
        for (var i = min; i <= max; i += step) {
            input.push(i);
        }
        return input;
    };

    $scope.Info = function (x) {
        $location.path('/pointinfo/' + x);
        $location.replace();
    };

    $scope.SmallToBig = false;
    $scope.byWhat = 'Rating';
    $scope.sortBy = "";
    $scope.changeStatus = function () {
        $scope.SmallToBig = !$scope.SmallToBig;
        $scope.ByUser = false;
    }
    $scope.changeBy = function () {
        $scope.ByUser = false;
        if ($scope.byWhat == 'Rating') {
            $scope.byWhat = 'CategoryID';
        }
        else {
            $scope.byWhat = 'Rating';
        }
    }
    function deleteFromArr(id) {
        var arr = $scope.points;
        for (var i = 0; i < arr.length; i++) {

            if (arr[i].PointID == id) {
                $scope.points.splice(i, 1);

            }
        }
    }

    $scope.SaveFavorite = function () {
        $http.get(URL + 'tokenAuthentication/Users/AllFavoritePoints')
            .then(Response => {
                $scope.pointsToCheck = Response.data;
                var arrDB = $scope.pointsToCheck;
                var arrLocal = localStorageService.keys();
                for (var i = 0; i < arrLocal.length; i++) {
                    if (!arrDBConitains(arrLocal[i], arrDB)) {
                        $http.post(URL + 'tokenAuthentication/Users/AddFavoritePoint', { pointID: arrLocal[i] })
                            .then(Response => { })
                    }
                }
                for (var i = 0; i < arrDB.length; i++) {
                    if (!arrLocalConitains(arrDB[i].PointID, arrLocal)) {
                        $http.delete(URL + 'tokenAuthentication/Users/RemoveFavoritePoint/' + arrDB[i].PointID)
                            .then(Response => { })
                    }
                }
            })
    }

    function arrDBConitains(id, arrDB) {
        for (var i = 0; i < arrDB.length; i++) {
            if (arrDB[i].PointID == id)
                return true;
        }
        return false;
    }
    function arrLocalConitains(id, arrLocal) {
        for (var i = 0; i < arrLocal.length; i++) {
            if (arrLocal[i] == id)
                return true;
        }
        return false;
    }


    $scope.deleteLocally = function (id) {
        localStorageService.remove(id);
        deleteFromArr(id);
        var arr = localStorageService.get('fav');
        for (var i = 0; i < arr.length; i++) {

            if (arr[i].PointID == id) {
                arr.splice(i, 1);

            }
        }
        localStorageService.set('fav', arr);

    }

    $scope.openModal = function () {
        $scope.m = true;



    }
    $scope.ReviewThankYou = false;
    $scope.RateThankYou = false;
    $scope.RateError = false;
    $scope.ReviewError = false;
    $scope.Review = { pointID: "", description: "" };
    $scope.Rate = { pointID: "", ranking: "" };

    $scope.Rating = function (x) {
        $scope.Rate.pointID = x;
        if (parseFloat($scope.Rate.ranking) >= parseFloat(1) && parseFloat($scope.Rate.ranking) <= parseFloat(5)) {
            $scope.RateError = false;
            $scope.RateThankYou = true;
            $http.post(URL + 'tokenAuthentication/Users/Rate', $scope.Rate)
                .then(Response => { });
        }


        else {

            $scope.RateError = true;
            $scope.Rate.ranking = "";
        }
    }

    $scope.GiveReview = function (x) {
        $scope.Review.pointID = x;
        if ($scope.Review.description == "") {
            $scope.ReviewError = true;
        }
        else {
            $scope.ReviewError = false;
            $scope.ReviewThankYou = true;
            $http.post(URL + 'tokenAuthentication/Users/Review', $scope.Review)
                .then(Response => { });
        }

    }
    function findIndex(id) {
        for (var i = 0; i < $scope.points.length; i++) {
            if ($scope.points[i].PointID == id) {
                return i;
            }
        }
    }


    $scope.Reset = function (x) {
        $scope.ReviewError = false;
        $scope.RateError = false;
        $scope.Review.description = "";
        $scope.Rate.ranking = "";
        $scope.RateThankYou = false;
        $scope.ReviewThankYou = false;

        $http.get(URL + "guests/Information/" + x)
            .then(Response => {
                var favArrTemp=localStorageService.get('fav');
                
                for(var i=0; i<favArrTemp.length;i++){
                    if (favArrTemp[i].PointID==x){
                        favArrTemp[i]=Response.data.point[0];
                    }
                localStorageService.set('fav',favArrTemp);    
                }
                localStorageService.set(x, Response.data.point[0]);
                $scope.points[findIndex(x)] = Response.data.point[0];

            })

    }
    $scope.PlaceError = false;

    $scope.firstPlace = { f: "" };
    $scope.secondPlace = { f: "" };
    $scope.Changeto = function () {
        $scope.ByUser = true;
        $scope.byWhat = "";
        $scope.SmallToBig = false;

    }
    $scope.Changefrom = function () {
        $scope.ByUser = false;
        $scope.byWhat = "Rating";
        $scope.SmallToBig = false;

    }
    $scope.SortMy = function () {
      
        if (parseInt($scope.firstPlace.f) == parseInt($scope.secondPlace.f) || $scope.firstPlace.f == undefined || $scope.secondPlace.f == undefined || $scope.firstPlace.f == "" || $scope.secondPlace.f == "") {
           
         
            $scope.PlaceError = true;
          
        }
        else {

            $scope.PlaceError = false;
            $scope.temp = $scope.points[parseInt($scope.firstPlace.f - 1)];
            $scope.points[parseInt($scope.firstPlace.f - 1)] = $scope.points[parseInt($scope.secondPlace.f - 1)];
            $scope.points[parseInt($scope.secondPlace.f - 1)] = $scope.temp;
            localStorageService.set('fav', $scope.points);
          
        }
    }
}])