app.controller('register', ['$scope', '$http', '$location', function ($scope, $http, $location) {
    let URL='http://localhost:3000/';
    $scope.success=true;
    $scope.empty = [];
    $scope.uservalid = [];
    $http.get(URL+'guests/Countries', $scope.user)
        .then(Response => {
            $scope.countries = Response.data;
           
        })
    $scope.country = { cou: "Israel" };
    $scope.user = {
        FirstName: "",
        LastName: "",
        UserName: "",
        Password: "",
        City: "",
        Country: "",
        Email: "",
        Question1: "What is the name of your school?",
        Answer1: "",
        Question2: "What is your pet name?",
        Answer2: "",
        Categories: []
    }
    $scope.boolCategories = false;

    $scope.register = function () {
        $scope.user.Country = $scope.country.cou;
       

        if ($scope.user.FirstName == undefined || $scope.user.FirstName == "")
            $scope.empty[0] = true;
        else
            $scope.empty[0] = false;
        if ($scope.user.LastName == undefined || $scope.user.LastName == "")
            $scope.empty[1] = true;
        else
            $scope.empty[1] = false;
        if ($scope.user.UserName == undefined || $scope.user.userName == "")
            $scope.empty[2] = true;
        else
            $scope.empty[2] = false;
        if ($scope.user.Password == undefined || $scope.user.Password == "")
            $scope.empty[3] = true;
        else
            $scope.empty[3] = false;
        if ($scope.user.City == undefined || $scope.user.City == "")
            $scope.empty[4] = true;
        else
            $scope.empty[4] = false;

        if ($scope.user.Email == undefined || $scope.user.Email == "")
            $scope.empty[5] = true;
        else
            $scope.empty[5] = false;
        if ($scope.user.Answer1 == undefined || $scope.user.Answer1 == "")
            $scope.empty[6] = true;
        else
            $scope.empty[6] = false;
        if ($scope.user.Answer2 == undefined || $scope.user.Answer2 == "")
            $scope.empty[7] = true;
        else
            $scope.empty[7] = false;
        $scope.ready = true;
        for (var i = 0; i < 7; i++) {
            if ($scope.empty[i] == true) {
                $scope.ready = false;
            }

        }
        if ($scope.ready) {
            var temp = "";
            $scope.countCat = 0;
            $scope.lastSaved = $scope.user.Categories;
            if ($scope.user.Categories[0] == true) {
                temp = "1";
                $scope.countCat += 1;
            }
            if ($scope.user.Categories[1] == true) {

                if ($scope.user.Categories[0] == true) {
                    temp = temp + ",";
                }
                temp = temp + "2";
                $scope.countCat += 1;
            }
            if ($scope.user.Categories[2] == true) {

                if ($scope.user.Categories[1] == true || $scope.user.Categories[0] == true) {
                    temp = temp + ",";
                }
                temp = temp + "3";
                $scope.countCat += 1;
            }
            if ($scope.user.Categories[3] == true) {

                if ($scope.user.Categories[2] == true || $scope.user.Categories[1] == true || $scope.user.Categories[0] == true) {
                    temp = temp + ",";
                }
                temp = temp + "4";
                $scope.countCat += 1;
            }
            $scope.user.Categories = temp;
           
            if (parseFloat($scope.countCat) >= parseFloat(2)) {
                $scope.boolCategories = false;
                $http.post(URL+'guests/RegisterUser', $scope.user)
                    .then(Response => {
                        if (Response.data) {
                            $location.path('/');
                            $location.replace();
                        }
                        else {
                            $scope.success=false;
                            $scope.user.Categories = $scope.lastSaved;
                        }

                    })
            }
            else {
                $scope.boolCategories = true;
                $scope.user.Categories = $scope.lastSaved;

            }
        }
    }





}])