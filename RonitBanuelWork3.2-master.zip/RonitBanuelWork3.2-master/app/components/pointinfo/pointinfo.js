app.controller('pointinfo', ['localStorageService', '$scope', '$http', function (localStorageService, $scope, $http) {
    let URL = 'http://localhost:3000/';
    $scope.login = false;
    if (localStorageService.get('token') != null)
        $scope.login = true;

    $scope.PointID = document.URL.split("/")[6];

    $http.get(URL + "guests/Information/" + $scope.PointID)
        .then(Response => {
            $scope.points = Response.data;
            $scope.review1 = $scope.points.response[0].Review;
            $scope.review2 = $scope.points.response[1].Review;
        })

    $scope.changeLocally = function () {
        if ($scope.ifContains()) {
            localStorageService.remove($scope.PointID);

            $scope.fav = localStorageService.get('fav');
            deleteFromArr($scope.PointID);
            localStorageService.set('fav', $scope.fav);
        }
        else {
            localStorageService.set($scope.PointID, $scope.points.point[0]);
            $scope.fav = localStorageService.get('fav');
            $scope.fav[$scope.fav.length] = $scope.points.point[0];
            localStorageService.set('fav', $scope.fav);
        }
    }
    function deleteFromArr(id) {
        var arr = $scope.fav;
        for (var i = 0; i < arr.length; i++) {

            if (arr[i].PointID == id) {
                $scope.fav.splice(i, 1);

            }
        }
    }




    $scope.ifContains = function () {
        var arr = localStorageService.keys();
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] == $scope.PointID) {
                return true;
            }
        }

        return false;
    }
}])