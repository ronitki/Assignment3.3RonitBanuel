app.controller('Map', ['$scope', '$http', '$location', function ($scope, $http, $location) {
    let URL='http://localhost:3000/';
    var mymap = L.map('mapid').setView([-33.859345, 151.208142], 13);
    L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
        maxZoom: 18,
        id: 'mapbox.streets',
        accessToken: 'pk.eyJ1IjoiYmFudWVsIiwiYSI6ImNqaWg2bTlrcTE2NDczcW54dDJ1OWZqbjkifQ.e7Xjr1eLRXsB-XR8AICBJw'
    }).addTo(mymap);

    for (var i = 1; i < 13; i++) {
        $http.get(URL+"guests/Information/" + i)
            .then(Response => {
                $scope.points = Response.data;
                addToMap($scope.points.point[0].XXcord, $scope.points.point[0].Y, $scope.points.point[0].Name, $scope.points.point[0].PointID);

            })

    }

    function addToMap(x, y, Name, PointID) {
        var marker = L.marker([x, y]).addTo(mymap);
        marker.bindPopup("You are in " + Name);


    }



}])