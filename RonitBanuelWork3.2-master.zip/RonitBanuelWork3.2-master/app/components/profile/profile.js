app.controller('profile', ['localStorageService', '$scope', '$http', '$location', function (localStorageService, $scope, $http, $location) {
    let URL = 'http://localhost:3000/';
    $scope.login = false;
    if (localStorageService.get('token') != null)
        $scope.login = true;
       
    $http.defaults.headers.common['x-access-token'] = localStorageService.get('token');
    $scope.length = -1;
    $scope.favPoints = [];
    if (localStorageService.keys().length == 3) {
        $http.get(URL + 'tokenAuthentication/Users/AllFavoritePoints')
            .then(Response => {
                $scope.allfavpoints = Response.data;
               
                var arr = $scope.allfavpoints;
                for (var i = 0; i < arr.length; i++) {
                    localStorageService.set(arr[i].PointID, arr[i]);
                }
                localStorageService.set('fav', arr);

            })
    }
    if (localStorageService.keys().length < 5) {
        $http.get(URL + "tokenAuthentication/Users/FavoritePoints")
            .then(Response => {
                $scope.favPoints = Response.data;

                if ($scope.favPoints == 'you dont have any saved points') {
                    $scope.length = 0;
                    $scope.favPoints = [];
                }


            });
    }
    else {
        
        var key1 = localStorageService.keys()[0];
        var key2 = localStorageService.keys()[1];
        $scope.favPoints[0] = localStorageService.get(key1);
        $scope.favPoints[1] = localStorageService.get(key2);

    }
    $scope.load = true;

    $scope.deleteLocally = function (id) {
        localStorageService.remove(id);
        $scope.fav = localStorageService.get('fav');

        var arr = $scope.fav;
        for (var i = 0; i < arr.length; i++) {

            if (arr[i].PointID == id) {
                $scope.fav.splice(i, 1);

            }
        }
        localStorageService.set('fav', $scope.fav);
        if (localStorageService.keys().length < 5) {
            $http.get(URL+"tokenAuthentication/Users/FavoritePoints")
                .then(Response => {
                    $scope.favPoints = Response.data;

                    if ($scope.favPoints == 'you dont have any saved points') {
                        $scope.length = 0;
                        $scope.favPoints = [];
                    }


                });
        }
        else {
            var key1 = localStorageService.keys()[0];
            var key2 = localStorageService.keys()[1];
            $scope.favPoints[0] = localStorageService.get(key1);
            $scope.favPoints[1] = localStorageService.get(key2);

        }

    }
    $http.get(URL + "tokenAuthentication/Users/PopularPoints")
        .then(Response => {
            $scope.popPoints = Response.data;
            $scope.load = false;
        });
    $scope.Info = function (x) {

        $location.path('/pointinfo/' + x);
        $location.replace();
    };

    $scope.changeLocally = function (id) {

        if ($scope.ifContains(id)) {
            localStorageService.remove(id);
            $scope.fav = localStorageService.get('fav');

            var arr = $scope.fav;
            for (var i = 0; i < arr.length; i++) {

                if (arr[i].PointID == id) {
                    $scope.fav.splice(i, 1);

                }
            }
            localStorageService.set('fav', $scope.fav);


        }
        else {
            $scope.fav = localStorageService.get('fav');
            if ($scope.popPoints[0][0].PointID == id) {
                localStorageService.set(id, $scope.popPoints[0][0]);
                $scope.fav[$scope.fav.length] = $scope.popPoints[0][0];
                localStorageService.set('fav', $scope.fav);

            }
            else {
                localStorageService.set(id, $scope.popPoints[1][0]);
                $scope.fav[$scope.fav.length] = $scope.popPoints[1][0];
                localStorageService.set('fav', $scope.fav);
            }

        }
    }

    $scope.ifContains = function (id) {
        var arr = localStorageService.keys();

        for (var i = 0; i < arr.length; i++) {
            if (arr[i] == id) {
                return true;
            }
        }

        return false;
    }


}])