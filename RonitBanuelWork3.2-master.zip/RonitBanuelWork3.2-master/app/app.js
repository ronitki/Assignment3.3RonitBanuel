var app = angular.module('Banu-Ron', ['ngRoute','LocalStorageModule']);
app.config(function ($routeProvider) {
    
    $routeProvider.when('/', {
        controller: 'homepage',
        templateUrl: 'components/homepage/homepage.html'
    })
    $routeProvider.when('/profile', {
        controller: 'profile',
        templateUrl: 'components/profile/profile.html'
    })
    $routeProvider.when('/register', {
        controller: 'register',
        templateUrl: 'components/register/register.html'
    })
    $routeProvider.when('/RetrievePass', {
        controller: 'RetrievePass',
        templateUrl: 'components/RetrievePass/RetrievePass.html'
    })
    $routeProvider.when('/about', {
        controller: 'about',
        templateUrl: 'components/about/about.html'
    })
    $routeProvider.when('/points', {
        controller: 'points',
        templateUrl: 'components/points/points.html'
    })
    $routeProvider.when('/pointinfo/:id', {
        controller: 'pointinfo',
        templateUrl: 'components/pointinfo/pointinfo.html'
    })
    $routeProvider.when('/favoritepoint', {
        controller: 'favoritepoint',
        templateUrl: 'components/favoritepoint/favoritepoint.html'
    })
    $routeProvider.when('/map', {
        controller: 'Map',
        templateUrl: 'components/Map/Map.html'
    })
    
       
});