app.controller('index', ['localStorageService', '$scope', '$http', '$location', function (localStorageService, $scope, $http, $location) {
    
     var x = localStorageService.get('name');
     var y = localStorageService.get('token');
     if (x != null && y!=null )
         toLog(x);
   
    $scope.logout = function () {
        localStorageService.remove('token');
       // localStorageService.remove('name');
        $location.path('/');
        $location.replace();
        $scope.name = "guest";
        toLogout();
    }


}])

function toLog(name) {
    document.getElementById("fav").style.display = "block";
    document.getElementById("prof").style.display = "block";
    document.getElementById("reg").style.display = "none";
    document.getElementById("logout").style.display = "block";
    document.getElementById("home").style.display = "none";
    document.getElementById("name").innerHTML = "<span style='left: -57%;position: relative;' >Hello " + name + "</span>"
   
}
function toLogout() {
    document.getElementById("fav").style.display = "none";
    document.getElementById("prof").style.display = "none";
    document.getElementById("reg").style.display = "block";
    document.getElementById("logout").style.display = "none";
    document.getElementById("home").style.display = "block";
    document.getElementById("name").innerHTML = "<span style='left: 14%;position: relative;' >Hello Guest</span>"
   
}